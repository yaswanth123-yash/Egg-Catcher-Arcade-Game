"""Egg Catcher: entry point, input handling and rendering."""
import json
import os
import sys

import pygame

import settings as S
from game_state import GameState

HIGH_SCORE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "highscore.json")


def load_high_score():
    try:
        with open(HIGH_SCORE_FILE) as f:
            return int(json.load(f).get("high", 0))
    except (OSError, ValueError, json.JSONDecodeError):
        return 0


def save_high_score(value):
    try:
        with open(HIGH_SCORE_FILE, "w") as f:
            json.dump({"high": value}, f)
    except OSError:
        pass  # not being able to save is not fatal


def build_background():
    """Pre-render the static background once instead of every frame."""
    bg = pygame.Surface((S.SCREEN_WIDTH, S.SCREEN_HEIGHT))
    bg.fill(S.SKY)
    ground = pygame.Rect(0, S.SCREEN_HEIGHT - 20, S.SCREEN_WIDTH, 20)
    pygame.draw.rect(bg, S.GRASS, ground)
    return bg.convert()


def draw_text(surface, font, text, color, **anchor):
    img = font.render(text, True, color)
    surface.blit(img, img.get_rect(**anchor))


def draw_hud(surface, font, game, high):
    draw_text(surface, font, f"Score: {game.score}", S.BLACK, topleft=(12, 10))
    draw_text(surface, font, f"Level {game.level}", S.BLACK, midtop=(S.SCREEN_WIDTH // 2, 10))
    draw_text(surface, font, f"Best: {high}", S.BLACK, topleft=(12, 40))
    for i in range(game.lives):
        x = S.SCREEN_WIDTH - 30 - i * 28
        pygame.draw.circle(surface, S.HEART, (x, 24), 10)


def main():
    pygame.init()
    screen = pygame.display.set_mode((S.SCREEN_WIDTH, S.SCREEN_HEIGHT))
    pygame.display.set_caption(S.TITLE)
    clock = pygame.time.Clock()
    font = pygame.font.SysFont("arial", 26, bold=True)
    big = pygame.font.SysFont("arial", 56, bold=True)
    background = build_background()

    game = GameState()
    high = load_high_score()
    paused = False

    running = True
    while running:
        # Cap dt so a stall (window drag, etc.) can't teleport eggs
        dt = min(clock.tick(S.FPS) / 1000.0, 0.05)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_p and not game.game_over:
                    paused = not paused
                elif event.key == pygame.K_r and game.game_over:
                    game.reset()

        keys = pygame.key.get_pressed()
        direction = (keys[pygame.K_RIGHT] or keys[pygame.K_d]) - (keys[pygame.K_LEFT] or keys[pygame.K_a])

        if not paused:
            game.update(dt, direction)

        if game.score > high:
            high = game.score
            if game.game_over:
                save_high_score(high)

        screen.blit(background, (0, 0))
        for egg in game.eggs:
            egg.draw(screen)
        game.basket.draw(screen)
        draw_hud(screen, font, game, high)

        if paused:
            draw_text(screen, big, "PAUSED", S.BLACK, center=(S.SCREEN_WIDTH // 2, S.SCREEN_HEIGHT // 2))
        if game.game_over:
            draw_text(screen, big, "GAME OVER", S.BLACK, center=(S.SCREEN_WIDTH // 2, S.SCREEN_HEIGHT // 2 - 30))
            draw_text(screen, font, f"Final score: {game.score}", S.BLACK, center=(S.SCREEN_WIDTH // 2, S.SCREEN_HEIGHT // 2 + 25))
            draw_text(screen, font, "Press R to restart or ESC to quit", S.BLACK, center=(S.SCREEN_WIDTH // 2, S.SCREEN_HEIGHT // 2 + 65))

        pygame.display.flip()

    save_high_score(high)
    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
