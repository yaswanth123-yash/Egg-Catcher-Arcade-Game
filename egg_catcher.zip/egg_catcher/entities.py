"""Game objects: Basket and Egg. Each handles its own update and drawing."""
import random

import pygame

import settings as S


class Basket:
    def __init__(self):
        self.rect = pygame.Rect(0, 0, S.BASKET_WIDTH, S.BASKET_HEIGHT)
        self.rect.midbottom = (S.SCREEN_WIDTH // 2, S.SCREEN_HEIGHT - S.BASKET_BOTTOM_MARGIN)
        self.x = float(self.rect.x)

    def update(self, dt, direction):
        self.x += direction * S.BASKET_SPEED * dt
        self.x = max(0, min(self.x, S.SCREEN_WIDTH - self.rect.width))
        self.rect.x = round(self.x)

    def draw(self, surface):
        pygame.draw.rect(surface, S.BASKET_COLOR, self.rect, border_radius=8)
        rim = pygame.Rect(self.rect.x - 4, self.rect.y, self.rect.width + 8, 10)
        pygame.draw.rect(surface, S.BASKET_RIM, rim, border_radius=5)


class Egg:
    NORMAL, GOLD, BAD = "normal", "gold", "bad"

    def __init__(self, fall_speed):
        roll = random.random()
        if roll < S.BAD_CHANCE:
            self.kind = Egg.BAD
        elif roll < S.BAD_CHANCE + S.GOLD_CHANCE:
            self.kind = Egg.GOLD
        else:
            self.kind = Egg.NORMAL

        self.rect = pygame.Rect(0, 0, S.EGG_WIDTH, S.EGG_HEIGHT)
        self.rect.x = random.randint(0, S.SCREEN_WIDTH - S.EGG_WIDTH)
        self.rect.y = -S.EGG_HEIGHT
        self.y = float(self.rect.y)
        # Small random variation so eggs don't fall in lockstep
        self.speed = fall_speed * random.uniform(0.9, 1.15)

    @property
    def color(self):
        return {
            Egg.NORMAL: S.EGG_COLOR,
            Egg.GOLD: S.GOLD_EGG_COLOR,
            Egg.BAD: S.BAD_EGG_COLOR,
        }[self.kind]

    def update(self, dt):
        self.y += self.speed * dt
        self.rect.y = round(self.y)

    def is_off_screen(self):
        return self.rect.top > S.SCREEN_HEIGHT

    def draw(self, surface):
        pygame.draw.ellipse(surface, self.color, self.rect)
        pygame.draw.ellipse(surface, S.BLACK, self.rect, 2)
