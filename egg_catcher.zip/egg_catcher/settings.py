"""All tunable constants in one place."""

SCREEN_WIDTH = 640
SCREEN_HEIGHT = 700
FPS = 60
TITLE = "Egg Catcher"

# Colours
SKY = (135, 206, 235)
GRASS = (88, 160, 80)
WHITE = (255, 255, 255)
BLACK = (30, 30, 30)
EGG_COLOR = (255, 248, 225)
GOLD_EGG_COLOR = (255, 215, 0)
BAD_EGG_COLOR = (90, 70, 60)
BASKET_COLOR = (160, 100, 50)
BASKET_RIM = (120, 70, 30)
HEART = (220, 50, 70)

# Basket
BASKET_WIDTH = 100
BASKET_HEIGHT = 40
BASKET_SPEED = 520  # pixels per second
BASKET_BOTTOM_MARGIN = 30

# Eggs
EGG_WIDTH = 28
EGG_HEIGHT = 36
START_FALL_SPEED = 200      # pixels per second
START_SPAWN_INTERVAL = 1.0  # seconds between eggs
GOLD_CHANCE = 0.10
BAD_CHANCE = 0.12

# Scoring and lives
START_LIVES = 3
POINTS_NORMAL = 1
POINTS_GOLD = 5

# Progressive difficulty
LEVEL_EVERY_POINTS = 10
SPEED_STEP = 35             # fall speed added per level
SPAWN_INTERVAL_STEP = 0.07  # spawn interval removed per level
MAX_FALL_SPEED = 650
MIN_SPAWN_INTERVAL = 0.35
