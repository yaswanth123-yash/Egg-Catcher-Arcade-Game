# Egg Catcher: Arcade Game (Python + pygame)

Catch falling eggs in your basket. Miss a good egg and you lose a life. The game speeds up as your score grows.

## Run it

```bash
pip install -r requirements.txt
python main.py
```

## Controls

| Key | Action |
|-----|--------|
| ← / → or A / D | Move basket |
| P | Pause |
| R | Restart (after game over) |
| Esc | Quit |

## Rules

- Normal egg (cream): +1 point
- Golden egg: +5 points
- Rotten egg (brown): do **not** catch it, it costs a life. Letting it fall is safe.
- Missing a normal or golden egg costs a life. You start with 3.
- Every 10 points raises the level: eggs fall faster and spawn more often (both capped).

## Structure

```
egg_catcher/
├── main.py         # Entry point: input, rendering, high score file
├── game_state.py   # Game logic: spawning, collisions, lives, levels
├── entities.py     # Basket and Egg classes
└── settings.py     # All tunable constants
```

## Performance notes

- Frame-rate independent movement using delta time (capped to avoid jumps after stalls)
- Static background rendered once and blitted each frame
- Eggs removed as soon as they are caught or leave the screen
- Game logic has no pygame display dependency, so it can be tested headless
