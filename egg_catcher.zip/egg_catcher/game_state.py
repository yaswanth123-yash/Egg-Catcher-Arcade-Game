"""Pure game logic (no drawing, no input), so it is easy to test."""
import random

import settings as S
from entities import Basket, Egg


class GameState:
    def __init__(self):
        self.reset()

    def reset(self):
        self.basket = Basket()
        self.eggs = []
        self.score = 0
        self.lives = S.START_LIVES
        self.level = 1
        self.spawn_timer = 0.0
        self.game_over = False
        self.caught = 0

    # Difficulty scales with level and is capped
    @property
    def fall_speed(self):
        return min(S.START_FALL_SPEED + (self.level - 1) * S.SPEED_STEP, S.MAX_FALL_SPEED)

    @property
    def spawn_interval(self):
        return max(S.START_SPAWN_INTERVAL - (self.level - 1) * S.SPAWN_INTERVAL_STEP, S.MIN_SPAWN_INTERVAL)

    def _update_level(self):
        self.level = 1 + self.score // S.LEVEL_EVERY_POINTS

    def update(self, dt, direction):
        if self.game_over:
            return

        self.basket.update(dt, direction)

        self.spawn_timer += dt
        if self.spawn_timer >= self.spawn_interval:
            self.spawn_timer -= self.spawn_interval
            self.eggs.append(Egg(self.fall_speed))

        remaining = []
        for egg in self.eggs:
            egg.update(dt)
            if egg.rect.colliderect(self.basket.rect):
                self._on_catch(egg)
            elif egg.is_off_screen():
                self._on_miss(egg)
            else:
                remaining.append(egg)
        self.eggs = remaining

        if self.lives <= 0:
            self.lives = 0
            self.game_over = True

    def _on_catch(self, egg):
        if egg.kind == Egg.BAD:
            self.lives -= 1
        else:
            self.score += S.POINTS_GOLD if egg.kind == Egg.GOLD else S.POINTS_NORMAL
            self.caught += 1
            self._update_level()

    def _on_miss(self, egg):
        # Only good eggs cost a life when missed
        if egg.kind != Egg.BAD:
            self.lives -= 1
